# include <stdio.h>
int main()
{
    float p,r,t,si;
    printf("enter the principle amount ");
    scanf("%f",&p);
    printf("enter the rate of intrest ");
    scanf("%f",&r);
    printf("enter the time period in a year ");
    scanf("%f",&t);
    si=p*r*t/100;
    printf("the intrest is %f",si);
    return 0;
}