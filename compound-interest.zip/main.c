#include <stdio.h>
#include <math.h>

int main() {
    double principal, rate, time, amount, compoundInterest;

    
    printf("Enter principal (amount): ");
    scanf("%lf", &principal);

    printf("Enter rate of interest: ");
    scanf("%lf", &rate);

    printf("Enter time (in years): ");
    scanf("%lf", &time);

    
    amount = principal * pow((1 + rate / 100), time);

    
    compoundInterest = amount - principal;

    printf("After %.2lf years:\n", time);
    printf("Total amount = %.4lf\n", amount);
    printf("Compound interest = %.4lf\n", compoundInterest);

    return 0;
}
