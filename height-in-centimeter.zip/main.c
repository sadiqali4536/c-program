#include <stdio.h>
int main()
{
    float height;
    printf("enter the height in centimeters :");
    scanf("%f",&height);
    if(height<150){
        printf("short stature\n");
    } else if(height >= 150 && height < 170){
        printf("average height\n");
    }else{
        printf("tall stature\n");
    }
    return 0;
}