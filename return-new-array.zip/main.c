
#include <stdio.h>

int main() {
    int size;
    printf("Enter the array size: ");
    scanf("%d", &size);
    
    int Array[size];
    printf("Enter %d elements: ", size);
    for (int i = 0; i < size; i++) {
        scanf("%d", &Array[i]);
    }
    printf("Even elements: ");
    for (int i = 0; i < size; i++) {
        if (i % 2 == 0) {
            printf("%d ", Array[i]);
        }
    }
    printf("\n");
    return 0;
}