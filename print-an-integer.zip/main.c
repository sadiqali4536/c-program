#include <stdio.h>
int main()
{
int number;

    printf("Enter a integer value:");
    scanf("%d",&number);
    printf("the integer value is: %d",number);
    return 0;
}