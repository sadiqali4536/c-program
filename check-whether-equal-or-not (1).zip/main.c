# include <stdio.h>
int main()
{
    int number1,number2;
    printf("enter the first integer: ");
    scanf("%d",&number1);
    printf("enter second number:");
    scanf("%d",&number2);
    if(number1==number2){
        printf("the integers are equal:.\n");
    } else {
        printf("the integer is not equal:.\n");
    }
    return 0;
}