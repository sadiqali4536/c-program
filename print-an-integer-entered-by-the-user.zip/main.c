# include <stdio.h>
int main()
{
    int number;
    printf("enter an integer:");
    scanf("%d",&number);
    printf("you enterd:%d\n",number);
    return 0;
}