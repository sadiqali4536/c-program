#include <stdio.h>
void main()
{
    int i,j,temp;
    int a[10]={10,5,55,51,84,72,61,1,122,109,};
    for(i=0; i<10; i++)
    {
        for(j = i+1; j<10; j++)
        {
            if(a[j] > a[i])
            {
                temp = a[i];
                a[i] = a[j];
                a[j] = temp;
            }
        }
    }
    printf("Printing Sorted Element List......\n");
    for(i=0;i<10;i++)
    {
        printf("%d\n",a[i]);
    }
    
}

