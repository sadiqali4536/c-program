#include <stdio.h>
int main()
{
    int temp;
    printf("enter any value:");
    scanf("%d",&temp);
    if(temp<0)
    printf("freezing wheather");
    else if(temp==0||temp<10)
    printf("very cold wheather");
    else if(temp==10||temp<20)
    printf("cold wheather");
    else if(temp==20||temp<30)
    printf("normal in temp");
    else if(temp==30||temp<40)
    printf("its hot");
    else
    printf("its very hot");
    return 0;
}