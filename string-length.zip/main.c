#include <stdio.h>
#include <string.h>

int main()
{
    char ch2[20];
    char ch1[20]={'h','u','k','s','d','\0'};
    printf("the string is %d \n",strlen(ch1));
    printf("Enter the string to compare :");
    scanf("%s",&ch2);
    if(strcmp(ch1,ch2)==0)
    printf("the string are same");
    else
    printf("the string not same");
    
    return 0;
}