# include <stdio.h>
int main()
{
    int number1,number2,temp=0;
    printf("enter the first number:");
    scanf("%d",&number1);
    printf("enter the second number:");
    scanf("%d",&number2);
    temp=number1;
    number1=number2;
    number2=temp;
    printf("first number = %d \nsecond number = %d",number1,number2);
    return 0;
    
}