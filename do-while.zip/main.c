# include <stdio.h>
int main()
{
    int week;
    do{
    printf("Enter week number (1-7):");
    scanf("%d",&week);
    switch (week)
    {
        case 1:
        printf("Monday");
        break;
        case 2:
        printf("Tuesday");
        break;
        case 3:
        printf("Wednesday");
        break;
        case 4:
        printf("Thursday");
        break;
        case 5:
        printf("friday");
        break;
        case 6:
        printf("saturday");
        break;
        case 7:
        printf("sunday");
        break;
        default:
        printf("invalid input! please eneter week number between1-7.");
    }
    }while (week< 1||week >7);
    return 0;
}