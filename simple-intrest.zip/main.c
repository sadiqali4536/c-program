# include <stdio.h>
int main()
{
    float principal,rate,time,simpleintrest;
    printf("enter principal (amount): ");
    scanf("%f",&principal);
    printf("enter rate: ");
    scanf("%F",&rate);
    printf("enter time (in years):");
    scanf("%f",&time);
    simpleintrest = (principal *rate *time) / 100;
    printf("simple interest =%.2f\n",simpleintrest);
    return 0;
    
}