# include <stdio.h>
int main()
{
   int length =10, breadth =10;
   int area =length * breadth;
   int perimeter = 2 * (length + breadth);
   
   printf("area of rectangle is: %d\n", area);
   printf("perimeter of rectangle is : %d\n",perimeter);
   return 0;
}
