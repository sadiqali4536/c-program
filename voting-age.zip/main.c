#include <stdio.h>
int main()
{
    int number; 
    printf("Enter your age");
    scanf("%d",&number); 
    (number>=18)? (printf("eligible for voting")):(printf("not eligible for voting age")); // conditional operator
    return 0;
}