#include <stdio.h>

int main()
{
int number;
    printf("ENTER A NUMBER");
    scanf("%d",&number);
    printf("THE CUBE OF NUMBER IS :%d",number*number*number);
    

    return 0;
}