#include <stdio.h>
int main()
{
    int number;
    printf("enter a number:");
    scanf("%d",&number);
    if(number%2==0||number%3==0)
    printf("the number is not prime");
    else
    printf("the number is prime");
    return 0;
}