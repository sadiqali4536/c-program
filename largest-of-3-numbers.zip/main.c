#include <stdio.h>

int main()
{
    double number1, number2, number3;
    
    printf("Enter three numbers: ");
    scanf("%lf %lf %lf", &number1, &number2, &number3);
    
    if (number1 >= number2 && number1 >= number3) {
        printf("%.21f is the largest number.\n", number1);
    } else if (number2 >= number1 && number2 >= number3) {
        printf("%.21f is the largest number.\n", number2);
    } else {
        printf("%.21f is the largest number.\n", number3);
    }
    
    return 0;
}
