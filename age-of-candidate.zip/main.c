# include <stdio.h>
int main()
{
    int vote_age;
    printf("input the age of candidate");
    scanf("%d",&vote_age);
    
    if(vote_age<18)
    {
        printf("sorry you are not eligible for caste your vote.\n");
        printf("you wouid be caste your vote after %d year.\n",18-vote_age);
    }
    else
    printf("congragulation ! your eligible for caste your vote");
    return 0;
}