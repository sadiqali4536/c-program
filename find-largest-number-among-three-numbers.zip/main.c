#include <stdio.h>
int main()
{
    float n1,n2,n3;
    printf("enter three different numbers:");
    scanf("%1f %1f %1f",&n1,&n2,&n3);
    if(n1>=n2 && n1>=n3)
    printf("%.2f is the largest number.\n",n1);
    else if (n2 >= n1 && n2 >=n3)
    printf("%.2f is the largest number.\n",n2);
    else
    printf("%.2f is the largest number.\n",n3);
    return 0;
}