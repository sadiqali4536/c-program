# include <stdio.h>
int main()
{
    float number1,number2,product;
    printf("enter first number:");
    scanf("%f",&number1);
    printf("enter second number:");
    scanf("%f",&number2);
    product=number1*number2;
    printf("product is %f",product);
    return 0;
}