#include <stdio.h>
int main()
{
    int number;
    printf("enter a number:");
    scanf("%d",&number);
    if(number%2==0)
    printf("%d its a even number",number);
    else
    printf("%d its a odd number",number);
    return 0;
}