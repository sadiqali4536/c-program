#include <stdio.h>
#include <string.h>
int main()
{
    char ch2[20];
    char ch1[20];
    printf("enter a 1st string : ");
    scanf("%s",ch1);
    printf("enter a 2nd string :");
    scanf("%s",ch2);
    strcat(ch1,ch2);
    printf("the string is :%s",ch1);
    
    return 0;
}