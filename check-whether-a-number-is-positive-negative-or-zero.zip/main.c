#include <stdio.h>
int main()
{
    int number;
    printf("enter a number:");
    scanf("%d",&number);
    if(number>0)
    printf("%d is a positive: .\n",number);
    else if(number<0)
    printf("%d is a negative: .\n",number);
    else
    printf("you entered number is zero .\n");
    return 0;
    
}