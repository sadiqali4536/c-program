#include <stdio.h>
int main()
{
int choice;
int n1,n2,r ;
printf("simple calculator\n");
printf("1.Addition\n");
printf("2.Substraction\n");
printf("3.Multiplication\n");
printf("4.Division\n");
printf("Enter your choice(1-4):");
scanf("%d",&choice);
 
printf("Enter two numbers:");
scanf("%d%d",&n1,&n2);
switch (choice){
    case 1:
    r=n1+n2;
    printf("Result:%d+%d=%d\n",n1,n2,r);
    break;
    case 2:
    r=n1-n2;
    printf("Result:%d-%d=%d\n",n1,n2,r);
    break;
    case 3:
    r=n1*n2;
    printf("Result:%d*%d=%d\n",n1,n2,r);
    break;
    case 1-4:
    if(n2!=0){
    r=n1/n2;
    printf("Result:%d/%d+%d\n",n1,n2,r);
}
break;
default:
printf("Invalid choice.please enter a numbers between 1 and 4.\n");
}
return 0;
}