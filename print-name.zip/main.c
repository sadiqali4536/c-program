#include <stdio.h>

int main()
{
    char name;
    printf("sadiq ");
    return 0;
}
