#include <stdio.h>
#include <string.h>

int main()
{
    char ch1[30]={'j','s','a','u','e','p','\0'};
    char ch2[30];
    strcpy(ch2,ch1);
    printf("the string is:%s",ch2);
    
    return 0;
}

