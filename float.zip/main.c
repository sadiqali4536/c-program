#include <stdio.h>

int main()
{
float number;
    printf("ENTER A NUMBER");
    scanf("%f",&number);
    printf("THE CUBE OF NUMBER IS :%f",number*number*number);
    

    return 0;
}